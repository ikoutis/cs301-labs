CS 301 - Unit III, Meeting 4: one trainable attention temperature

1. Install PyTorch in a Python environment if it is not already available.
   Follow the official setup instructions for your system:
   https://pytorch.org/get-started/locally/
   A CPU installation is sufficient.
2. Keep pytorch-temperature.py and results.json in the same directory.
3. Run: python pytorch-temperature.py

The program learns one scalar theta; tau = exp(theta) is always positive.
The fixed memory contains 40 examples, with 80 separate training queries and
160 separate validation queries. Only theta is passed to the SGD optimizer.
All observations are synthetic and are included; no dataset is downloaded.

The program prints the initial state, the first gradient and update, and the
result after 500 updates. It also writes pytorch-results.json. The supplied
copy records a verified CPU/float64 execution. Its assertions check the first
gradient by finite differences and compare the result with the lecture.

Expected final values (rounded):
  theta          -2.682999
  tau             0.068358
  training MSE    0.129176
  validation MSE  0.139597

Training loss changes the parameter. Validation measures predictions on
separate observations and never supplies a gradient.

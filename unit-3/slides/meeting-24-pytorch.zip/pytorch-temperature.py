"""Learn one attention temperature with PyTorch, using the lecture's fixed data.

Place this file beside results.json and run: python pytorch-temperature.py
Requires PyTorch. No data is downloaded. CPU and float64 make the numerical
comparison with the lecture's reference calculation reproducible.
"""
from pathlib import Path
import json
import math
import torch


def main():
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    data = json.loads(Path(__file__).with_name("results.json").read_text(encoding="utf-8"))["oneD"]

    def tensors(rows):
        return (torch.tensor([row["x"][0] for row in rows]),
                torch.tensor([row["y"] for row in rows]))

    keys, values = tensors(data["memory"])
    q_train, t_train = tensors(data["train"])
    q_valid, t_valid = tensors(data["valid"])
    theta = torch.nn.Parameter(torch.tensor(0.0))
    optimizer = torch.optim.SGD([theta], lr=0.2)

    def predict(q):
        tau = theta.exp()
        d2 = (q[:, None] - keys[None, :]).square()
        alpha = torch.softmax(-d2 / tau, dim=1)
        return alpha @ values

    def snapshot(step):
        with torch.no_grad():
            return dict(step=step, theta=theta.item(), tau=theta.exp().item(),
                        trainMSE=(predict(q_train) - t_train).square().mean().item(),
                        validMSE=(predict(q_valid) - t_valid).square().mean().item())

    # An independent central difference checks autograd's first gradient.
    with torch.no_grad():
        eps = 1e-5
        theta.fill_(eps)
        upper = (predict(q_train) - t_train).square().mean().item()
        theta.fill_(-eps)
        lower = (predict(q_train) - t_train).square().mean().item()
        theta.zero_()
    finite_difference = (upper - lower) / (2 * eps)

    initial = snapshot(0)
    initial_gradient = None
    one_step = None
    for step in range(500):
        optimizer.zero_grad()
        loss = (predict(q_train) - t_train).square().mean()
        loss.backward()
        if step == 0:
            initial_gradient = theta.grad.item()
        optimizer.step()
        if step == 0:
            one_step = snapshot(1)

    # Evaluation uses separate queries and creates no autograd graph.
    with torch.no_grad():
        valid_mse = (predict(q_valid) - t_valid).square().mean()
    final = snapshot(500)

    reference = data["trace"][-1]
    assert theta.numel() == 1
    assert optimizer.param_groups[0]["params"] == [theta]
    assert not any(t.requires_grad for t in (keys, values, q_train, t_train, q_valid, t_valid))
    assert math.isclose(initial_gradient, finite_difference, rel_tol=0, abs_tol=1e-8)
    assert math.isclose(one_step["theta"], -0.2 * initial_gradient, rel_tol=0, abs_tol=1e-12)
    for name in ("theta", "trainMSE", "validMSE"):
        assert math.isclose(final[name], reference[name], rel_tol=0, abs_tol=1e-10), name
    assert valid_mse.item() == final["validMSE"]
    initial["gradTheta"] = initial_gradient

    report = dict(torchVersion=torch.__version__, dtype="float64", device="cpu",
                  memoryCount=len(keys), trainingQueryCount=len(q_train),
                  validationQueryCount=len(q_valid), learningRate=0.2,
                  initial=initial, initialGradient=initial_gradient,
                  finiteDifference=finite_difference, oneStep=one_step, final=final,
                  checks="One scalar; fixed data; first gradient and update checked; final result matches lecture reference.")
    output = Path(__file__).with_name("pytorch-results.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

CS 301 - Unit 3, Meeting 5: Learning together

Extract this folder, then open m25-learning-from-others.html in a desktop browser.
The lecture works offline. Arrow keys navigate; Space reveals the next step.
O opens the overview. N opens instructor notes. F toggles fullscreen.
Use the annotation menu to back up writing before moving to another browser.
The instructor guide is m25-instructor-guide.html.
